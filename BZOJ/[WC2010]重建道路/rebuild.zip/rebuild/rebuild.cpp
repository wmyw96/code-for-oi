#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;

const int MAX_N = 100001, MAX_M = 200001;
const double INF = 1000000000;
int g[MAX_M], c[MAX_N], next[MAX_M], ok[MAX_M], nm;
double cost[MAX_M], a[MAX_N], nd[MAX_N];
int pr[MAX_N], s[MAX_N], Q[MAX_N], pre[MAX_N], dep[MAX_N];
int n, m, L, R, nowsize, ctr, prmn, dnow;
double ans;
int x[MAX_N], y[MAX_N], w[MAX_N];

struct TTT{
       int l, r, t[100001];
       double Q[100001];
       void clear(int n){
            //for (int i = 0; i <= n; ++i) Q[i] = 0;
            l = 1, r = 0;
            memset(Q, 0, sizeof Q);
            memset(t, 0, sizeof t);
       }
       void upd(int tt){
            while (l <= r && t[l] > tt) l++;
       }
       void push(double ret, int time){
            while (l <= r && Q[r] <= ret) r--;
            Q[++r] = ret;
            t[r] = time;
       }
       double get(){
              if (l <= r) return Q[l];
              return -1000000000.0;
       }
}T;

void findroot(int i, int pre){
     //ok
     s[i] = 1, pr[i] = 0;
     for (int k = c[i]; k != -1; k = next[k]){
         int j = g[k];
         if (j != pre && ok[k]){
            findroot(j, i);
            s[i] += s[j];
            pr[i] = max(pr[i], s[j]);
         }
     }
     pr[i] = max(pr[i], nowsize - s[i]);
     if (pr[i] < prmn){
        prmn = pr[i];
        ctr = i;
     }
}

void calcdep(int i, int pre, int dd){
     dnow = max(dnow, dd);
     for (int k = c[i]; k != -1; k = next[k]){
         int j = g[k];
         if (j != pre && ok[k])
            calcdep(j, i, dd + 1);
     }
}

void dfs_upd(int i, int pre, int dd, double now){
     printf("%d\n", i);
     a[dd] = max(a[dd], now);
     //printf("dfs_upd() %.3f %d %d\n", a[dd], i, dd);
     for (int k = c[i]; k != -1; k = next[k]){
         int j = g[k];
         if (j != pre && ok[k]) dfs_upd(j, i, dd + 1, now + cost[k]);
     }
}

void getans(int ii, int jj, int dd, double now){
     //����ǰ���㵽��depΪk,��[max(L - k, 0), R - k]���ҵ����ֵ.
     Q[1] = ii;
     dep[0] = dd - 1;
     pre[1] = jj;
     dep[1] = dd;
     nd[1] = now;
     calcdep(ii, jj, dd);
     T.clear(dnow);
     for (int l = 1, r = 1; l <= r; ++l){
         if (dep[l] > R) return;
         if (dep[l] != dep[l - 1]){
            //printf("%d %d %d\n", dep[l], ii, l);
            T.upd(R - dep[l]);
            if (L - dep[l] >= 0)
               T.push(a[L - dep[l]], L - dep[l]);
            //printf("%.3f\n", T.get() + nd[l]);
            ans = max(ans, T.get() + nd[l]);
         }
         int i = Q[l];
         for (int k = c[i]; k != -1; k = next[k]){
             int j = g[k];
             if (j != pre[l] && ok[k]){
                Q[++r] = j;
                pre[r] = i;
                dep[r] = dep[l] + 1;
                nd[r] = nd[l] + cost[k];
             }
         }
     }
}

void calc(int i){
     
     //���ɼ����Ҫ����[0, dnow]������[R - dnow, R]
     //ͬʱ, ����ǰ���㵽��depΪk,��[max(L - k, 0), R - k]�и��� 
     dnow = 0;
     calcdep(i, -1, 0);
     a[0] = 0;
     for (int j = 1; j <= dnow; ++j) a[j] = -INF;
     for (int j = R - dnow; j <= R; ++j) a[j] = 0;
     for (int k = c[i]; k != -1; k = next[k]){
         int j = g[k];
         if (ok[k]){
            getans(j, i, 1, cost[k]);
            dfs_upd(j, i, 1, cost[k]);
         }
     }
     
     findroot(i, -1);
     for (int k = c[i]; k != -1; k = next[k]){
         int j = g[k];
         if (ok[k]){
            ok[k ^ 1] = 0;
            nowsize = prmn = s[j];
            findroot(j, -1);
            calc(ctr);
         }
     }
}

void addedge(int x, int y, double w){
     //ok
     g[nm] = y;
     next[nm] = c[x];
     c[x] = nm;
     cost[nm] = w;
     ok[nm] = 1;
     nm++;
}

double ck(double ww){
    //ok
    nm = 0;
    memset(c, -1, sizeof c);   
    for (int i = 1; i < n; ++i){
        addedge(x[i], y[i], w[i] - ww);
        addedge(y[i], x[i], w[i] - ww);
    }
    ans = -INF;
    nowsize = prmn = n;
    findroot(1, -1);
    //printf("%d\n", ctr);
    calc(ctr);
    return ans;
}

int main(){
    //ok
    scanf("%d", &n);
    scanf("%d%d", &L, &R);
    for (int i = 1; i < n; ++i){
        scanf("%d%d%d", &x[i], &y[i], &w[i]);
    }
    double l = 0, r = INF;
    //printf("%.3f\n", ck(2.5));
    while (l + 1e-5 < r){
          double mid = (l + r) / 2;
          printf("%.3f\n", mid);
          if (ck(mid) > 0) l = mid; else r = mid;
    }
    printf("%.3f\n", l);
}
